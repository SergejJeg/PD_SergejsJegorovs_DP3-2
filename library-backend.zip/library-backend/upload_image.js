const mysql = require('mysql');
const fs = require('fs');
const path = require('path');

// Configure the database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // replace with your MySQL username
  password: '', // replace with your MySQL password
  database: 'library'
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the database');

  // Path to the image file you want to upload
  const imagePath = path.join(__dirname, 'images\\cant.jpg');
  console.log(imagePath);
  
  // Read the image file
  fs.readFile(imagePath, (err, data) => {
    if (err) {
      console.error('Error reading the image file:', err);
      return;
    }

    // SQL query to insert the image into the books table
    const query = 'UPDATE users SET profile_image = ? WHERE username = ?';

    // Replace `1` with the actual ID of the book you want to update
    db.query(query, [data, '1'], (err, results) => {
      if (err) {
        console.error('Error inserting image into the database:', err);
        return;
      }
      console.log('Image inserted successfully:', results);

      // Close the database connection
      db.end((err) => {
        if (err) {
          console.error('Error closing the database connection:', err);
          return;
        }
        console.log('Database connection closed');
      });
    });
  });
});
