// Get all requirements
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;
app.use(bodyParser.json({ limit: '10gb' }));
app.use(bodyParser.urlencoded({ limit: '10gb', extended: true }));

app.use(cors());
app.use(express.json());

// Connect server to database
const db = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: '',
	database: 'library'
});
db.connect((err) => {
	if (err) {
		console.error('Error connecting to the database:', err);
		return;
	}
	console.log('Connected to the database');
});

// Sign-up endpoint
app.post('/api/signup', async (req, res) => {
	const { username, password } = req.body;

	if (!username || !password) {
		return res.status(400).json({ error: 'Username and password are required' });
	}

	try {
		const hashedPassword = await bcrypt.hash(password, 10);
		const query = 'INSERT INTO users (username, password) VALUES (?, ?)';

		db.query(query, [username, hashedPassword], (err, results) => {
			if (err) {
			if (err.code === 'ER_DUP_ENTRY') {
				return res.status(409).json({ error: 'Username already exists' });
			}
				console.error('Error saving user:', err);
				return res.status(500).json({ error: 'Error saving user' });
			}

			res.status(201).json({ message: 'User registered successfully' });
		});
		} catch (error) {
		console.error('Error hashing password:', error);
		res.status(500).json({ error: 'Error hashing password' });
	}
});

// Login endpoint
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    try {
        const query = 'SELECT * FROM users WHERE username = ?';

        db.query(query, [username], async (err, results) => {
            if (err) {
                console.error('Error finding user:', err);
                return res.status(500).json({ error: 'Error finding user' });
            }

            if (results.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            const user = results[0];
            const passwordMatch = await bcrypt.compare(password, user.password);

            if (!passwordMatch) {
                return res.status(401).json({ error: 'Incorrect password' });
            }

            res.status(200).json({ message: 'Login successful' });
        });
    } catch (error) {
        console.error('Error logging in user:', error);
        res.status(500).json({ error: 'Error logging in user' });
    }
});

// Update profile icon endpoint
app.post('/api/update-profile-icon', async (req, res) => {
    const { username, imageData } = req.body;

    if (!username || !imageData) {
        return res.status(400).json({ error: 'Username and image data are required' });
    }

    try {
        var base64Data = imageData.substring("data:image/png;base64,".length);
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        var bufferData = Buffer.from(byteArray);

        const updateQuery = 'UPDATE users SET profile_image = ? WHERE username = ?';
        const updateValues = [bufferData, username];

        db.query(updateQuery, updateValues, (err, results) => {
            if (err) {
                console.error('Error updating profile icon:', err);
                return res.status(500).json({ error: 'Error updating profile icon' });
            }

            res.status(200).json({ message: 'Profile icon updated successfully' });
        });
    } catch (error) {
        console.error('Error updating profile icon:', error);
        res.status(500).json({ error: 'Error updating profile icon' });
    }
});

// Update password endpoint
app.post('/api/update-password', async (req, res) => {
    const { username, currentPassword, newPassword } = req.body;

    if (!username || !currentPassword || !newPassword) {
        return res.status(400).json({ error: 'Username, current password, and new password are required' });
    }

    try {
        db.query('SELECT password FROM users WHERE username = ?', [username], async (err, results) => {
            if (err) {
                console.error('Error fetching user:', err);
                return res.status(500).json({ error: 'Error fetching user' });
            }

            if (results.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            const user = results[0];
            const passwordMatch = await bcrypt.compare(currentPassword, user.password);

            if (!passwordMatch) {
                return res.status(401).json({ error: 'Current password is incorrect' });
            }

            const hashedNewPassword = await bcrypt.hash(newPassword, 10);
            db.query('UPDATE users SET password = ? WHERE username = ?', [hashedNewPassword, username], (err, results) => {
                if (err) {
                    console.error('Error updating password:', err);
                    return res.status(500).json({ error: 'Error updating password' });
                }

                res.status(200).json({ message: 'Password updated successfully' });
            });
        });
    } catch (error) {
        console.error('Error updating password:', error);
        res.status(500).json({ error: 'Error updating password' });
    }
});

// Get user data endpoint
app.post('/api/user', async (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT username, profile_image, isAdmin, password FROM users WHERE username = ?';

    try {
        const results = await new Promise((resolve, reject) => {
            db.query(query, [username], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const user = results[0];
        const profileImage = user.profile_image ? user.profile_image.toString('base64') : null;

        if (typeof password !== 'string' || typeof user.password !== 'string') {
            return res.status(400).json({ error: 'Invalid password data' });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Passwords do not match' });
        }

        res.json({
            username: user.username,
            profile_image: profileImage,
            isAdmin: user.isAdmin === 1,
            adminpanel: user.isAdmin === 1 ? 'admin.html' : 'main.html'
        });

    } catch (err) {
        console.error('Error fetching user data:', err);
        res.status(500).json({ error: 'Error fetching user data' });
    }
});

// Serve user profile image as base64-encoded JSON
app.get('/api/user/:username/image', (req, res) => {
    const username = req.params.username;
    const query = 'SELECT profile_image FROM users WHERE username = ?';
    db.query(query, [username], (err, results) => {
        if (err) {
            console.error('Error fetching profile image:', err);
            res.status(500).json({ error: 'Error fetching profile image' });
            return;
        }
        if (results.length === 0 || !results[0].profile_image) {
            res.status(404).json({ error: 'Profile image not found' });
            return;
        }
        const profileImage = results[0].profile_image.toString('base64');
        res.json({ profile_image: profileImage });
    });
});

// Get genres endpoint
app.get('/api/genres', (req, res) => {
    db.query('SELECT * FROM genres', (err, results) => {
        if (err) {
            console.error('Error fetching genres:', err);
            res.status(500).json({ error: 'Error fetching genres' });
            return;
        }
        res.json(results);
    });
});

// Get books endpoint
app.post('/api/books', (req, res) => {
    const { genres, author } = req.body;

    if (genres.length === 0) {
        let query = `SELECT * FROM books`;
        let params = [];

        if (author) {
            query += `
        WHERE books.author LIKE ?`;
            params.push(`%${author}%`);
        }
        db.query(query, params, (err, results) => {
            if (err) {
                console.error('Error fetching books:', err);
                res.status(500).json({ error: 'Error fetching books' });
                return;
            }
            results.forEach(book => {
                if (book.image) {
                    book.image = book.image.toString('base64');
                }
            });
            res.json(results);
        });
    } else {
        const totalGenres = genres.length;
        let query = `
      SELECT DISTINCT books.id, books.title, books.image
      FROM books
      JOIN book_genres ON books.id = book_genres.book_id
    `;
        let params = [];

        if (genres.length > 0) {
            query += `
        WHERE book_genres.genre_id IN (?)`;
            params.push(genres);
        }

        if (author) {
            query += `
        AND books.author LIKE ?`;
            params.push(`%${author}%`);
        }

        query += `
      GROUP BY books.id
      HAVING COUNT(DISTINCT book_genres.genre_id) = ?`;

        params.push(totalGenres);

        db.query(query, params, (err, results) => {
            if (err) {
                console.error('Error fetching books:', err);
                res.status(500).json({ error: 'Error fetching books' });
                return;
            }
            results.forEach(book => {
                if (book.image) {
                    book.image = book.image.toString('base64');
                }
            });
            res.json(results);
        });
    }
});

// Endpoint to fetch book details by ID and check if it's in user's favorites
app.get('/api/book/:id', (req, res) => {
    const bookId = req.params.id;
    const username = req.query.username;

    const bookQuery = `
        SELECT books.id, books.title, books.author, books.description, books.text, books.image, GROUP_CONCAT(genres.name) AS genres
        FROM books
        LEFT JOIN book_genres ON books.id = book_genres.book_id
        LEFT JOIN genres ON book_genres.genre_id = genres.id
        WHERE books.id = ?
        GROUP BY books.id
    `;

    const favoriteQuery = `
        SELECT 1 FROM favorites WHERE book_id = ? AND user = ?
    `;

    db.query(bookQuery, [bookId], (err, bookResults) => {
        if (err) {
            console.error('Error fetching book details:', err);
            return res.status(500).json({ error: 'Error fetching book details' });
        }
        if (bookResults.length === 0) {
            return res.status(404).json({ error: 'Book not found' });
        }

        const book = bookResults[0];
        if (book.image) {
            book.image = book.image.toString('base64');
        }
        book.genres = book.genres ? book.genres.split(',') : [];

        db.query(favoriteQuery, [bookId, username], (favErr, favResults) => {
            if (favErr) {
                console.error('Error checking favorites:', favErr);
                return res.status(500).json({ error: 'Error checking favorites' });
            }
            book.isFavorite = favResults.length > 0;
            res.json(book);
        });
    });
});

// Add book to favorites endpoint
app.post('/api/favorite', (req, res) => {
    const { book_id, user } = req.body;

    if (!book_id || !user) {
        return res.status(400).json({ error: 'Book ID and user are required' });
    }

    const query = 'INSERT INTO favorites (book_id, user) VALUES (?, ?)';

    db.query(query, [book_id, user], (err, results) => {
        if (err) {
            console.error('Error adding book to favorites:', err);
            return res.status(500).json({ error: 'Error adding book to favorites' });
        }

        res.status(201).json({ message: 'Book added to favorites' });
    });
});

// Endpoint to remove a book from favorites
app.post('/api/unfavorite', (req, res) => {
    const { book_id, user } = req.body;

    const query = `
        DELETE FROM favorites WHERE book_id = ? AND user = ?
    `;

    db.query(query, [book_id, user], (err, results) => {
        if (err) {
            console.error('Error removing book from favorites:', err);
            return res.status(500).json({ error: 'Error removing book from favorites' });
        }
        res.sendStatus(200);
    });
});

// Endpoint to fetch favorite books for a user
app.post('/api/favorites', (req, res) => {
    const { username, genres } = req.body;

    if (!username) {
        return res.status(400).json({ error: 'Username is required' });
    }

    const query = `
    SELECT books.id, books.title, books.image
    FROM books
    JOIN favorites ON books.id = favorites.book_id
    WHERE favorites.user = ?
  `;

    db.query(query, [username], (err, results) => {
        if (err) {
            console.error('Error fetching favorite books:', err);
            return res.status(500).json({ error: 'Error fetching favorite books' });
        }
        results.forEach(book => {
            if (book.image) {
                book.image = book.image.toString('base64');
            }
        });
        res.json(results);
    });
});

// Add book endpoint
app.post('/api/add-book', async (req, res) => {
    const { name, description, image, text, author, genres } = req.body;

    if (!name || !description || !image || !text || !author || !genres) {
        return res.status(400).json({ error: 'Name, description, image, and text and genres are required' });
    }

    try {
        var base64Data = image.substring("data:image/png;base64,".length);
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        var bufferData = Buffer.from(byteArray);

        const query = 'INSERT INTO books (title, description, image, text, author) VALUES (?, ?, ?, ?, ?)';
        db.query(query, [name, description, bufferData, text, author], (err, results) => {
            if (err) {
                console.error('Error adding book:', err);
                return res.status(500).json({ error: 'Error adding book' });
            }
            const bookId = results.insertId;

            try {
                const genreValues = genres.map(genre => `(${bookId}, ${genre})`).join(', ');
                const genreQuery = `INSERT INTO book_genres (book_id, genre_id) VALUES ${genreValues}`;
                db.query(genreQuery);
            } catch (genreError) {
                console.error('Error adding book genres:', genreError);
                return res.status(500).json({ error: 'Error adding book genres' });
            }

            res.status(201).json({ message: 'Book added successfully' });
        });
    } catch (error) {
        console.error('Error adding book:', error);
        res.status(500).json({ error: 'Error adding book' });
    }
});

// Add genre endpoint
app.post('/api/add-genre', async (req, res) => {
    const { genre, admin, password } = req.body;

    const query = 'SELECT username, isAdmin, password FROM users WHERE username = ?';
    try {
        const results = await new Promise((resolve, reject) => {
            db.query(query, [admin], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        const user = results[0];
        if (typeof password !== 'string' || typeof user.password !== 'string') {
            return res.status(400).json({ error: 'Invalid password data' });
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Passwords do not match' });
        }
        if (user.isAdmin != 1) {
            return res.status(401).json({ error: 'No admin rights' });
        }
    } catch (err) {
        console.error('Error fetching user data:', err);
        res.status(500).json({ error: 'Error fetching user data' });
    }

    if (!genre) {
        return res.status(400).json({ error: 'Genre name is required' });
    }

    try {
        const query = 'INSERT INTO genres (name) VALUES (?)';

        db.query(query, [genre], (err, results) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    return res.status(409).json({ error: 'Genre already exists' });
                }
                console.error('Error adding genre:', err);
                return res.status(500).json({ error: 'Error adding genre' });
            }

            res.status(201).json({ message: 'Genre created successfully' });
        });
    } catch (error) {
        console.error('Error adding genre:', error);
        res.status(500).json({ error: 'Error adding genre' });
    }
});

// Remove genre endpoint
app.post('/api/remove-genres', async (req, res) => {
    const { genres, admin, password } = req.body;

    const query = 'SELECT username, isAdmin, password FROM users WHERE username = ?';
    try {
        const results = await new Promise((resolve, reject) => {
            db.query(query, [admin], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        const user = results[0];
        if (typeof password !== 'string' || typeof user.password !== 'string') {
            return res.status(400).json({ error: 'Invalid password data' });
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Passwords do not match' });
        }
        if (user.isAdmin != 1) {
            return res.status(401).json({ error: 'No admin rights' });
        }
    } catch (err) {
        console.error('Error fetching user data:', err);
        res.status(500).json({ error: 'Error fetching user data' });
    }

    try {
        const genresMap = genres.map(genre => parseInt(genre));
        const query = `DELETE FROM genres WHERE id IN (?)`;
        db.query(query, [genresMap]);
    } catch (genreError) {
        console.error('Error deleting genres:', genreError);
        return res.status(500).json({ error: 'Error deleting genres' });
    }
    res.status(201).json({ message: 'Genres deleted successfully' });
});

// Fetch users endpoint
app.get('/api/users', (req, res) => {
  db.query('SELECT id, username FROM users', (err, results) => {
    if (err) {
      console.error('Error fetching users:', err);
      res.status(500).json({ error: 'Error fetching users' });
      return;
    }
    res.json(results);
  });
});

// Remove user endpoint
app.delete('/api/delete-user/:userId', async (req, res) => {
    const { userId } = req.params;
    const { admin, password } = req.body;

    const adminQuery = 'SELECT isAdmin, password FROM users WHERE username = ?';
    try {
        const adminResults = await new Promise((resolve, reject) => {
            db.query(adminQuery, [admin], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (adminResults.length === 0) {
            return res.status(404).json({ error: 'Admin user not found' });
        }
        const adminUser = adminResults[0];
        if (typeof password !== 'string' || typeof adminUser.password !== 'string') {
            return res.status(400).json({ error: 'Invalid password data' });
        }
        const passwordMatch = await bcrypt.compare(password, adminUser.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Passwords do not match' });
        }
        if (adminUser.isAdmin !== 1) {
            return res.status(401).json({ error: 'No admin rights' });
        }
		
        const userToDelete = await new Promise((resolve, reject) => {
            db.query('SELECT isAdmin FROM users WHERE id = ?', [userId], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results[0]);
            });
        });
        if (userToDelete.isAdmin === 1) {
            return res.status(403).json({ error: 'Cannot delete admin user' });
        }
    } catch (err) {
        console.error('Error fetching admin user data:', err);
        res.status(500).json({ error: 'Error fetching admin user data' });
        return;
    }

    try {
        const query = 'DELETE FROM users WHERE id = ?';
        db.query(query, [userId], (err) => {
            if (err) {
                console.error('Error deleting user:', err);
                res.status(500).json({ error: 'Error deleting user' });
                return;
            }
            res.status(201).json({ message: 'User deleted successfully' });
        });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ error: 'Error deleting user' });
    }
});

// Remove book endpoint
app.delete('/api/delete-book/:bookID', async (req, res) => {
    const { bookID } = req.params;
    const { username, password } = req.body;

    const authorQuery = 'SELECT author FROM books WHERE id = ?';

    try {
        const [bookAuthor] = await new Promise((resolve, reject) => {
            db.query(authorQuery, [bookID], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (!bookAuthor) {
            return res.status(404).json({ error: 'Book not found' });
        }

        const isAdminQuery = 'SELECT isAdmin, password FROM users WHERE username = ?';
        const [user] = await new Promise((resolve, reject) => {
            db.query(isAdminQuery, [username], (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (typeof password !== 'string' || typeof user.password !== 'string') {
            return res.status(400).json({ error: 'Invalid password data' });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Passwords do not match' });
        }

        if (user.isAdmin !== 1 && user.username !== bookAuthor) {
            return res.status(401).json({ error: 'User is not authorized to delete this book' });
        }

        const deleteQuery = 'DELETE FROM books WHERE id = ?';
        db.query(deleteQuery, [bookID], (err) => {
            if (err) {
                console.error('Error deleting book:', err);
                res.status(500).json({ error: 'Error deleting book' });
                return;
            }
            res.status(201).json({ message: 'Book deleted successfully' });
        });

    } catch (error) {
        console.error('Error deleting book:', error);
        res.status(500).json({ error: 'Error deleting book' });
    }
});

// Output that server is active
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});