// Function to test sign-up endpoint
async function testSignUp() {
    try {
		
        const response = await fetch('http://localhost:3000/api/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
				username: 'testuser',
				password: 'testpassword'
			})
        });
        console.log(response);
    } catch (error) {
        console.error('Error testing sign-up:', error.response.data);
    }
}

// Function to test login endpoint
async function testLogin() {
    try {
        const response = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
				username: 'Admin',
				password: '1234'
			})
        });
        console.log(response);
    } catch (error) {
        console.error('Error testing login:', error.response.data);
    }
}

// Function to test create genre endpoint
async function createGenre() {
    try {
		const response = await fetch('http://localhost:3000/api/add-genre', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                genre: 'Tragedy', // Adjust genre name as needed
				admin: 'Admin', // Assuming an admin user is required
				password: '1234' // Admin user password
            })
        });
        console.log(response);
    } catch (error) {
        console.error('Error testing create genre:', error.response.data);
    }
}

// Function to test get user data endpoint
async function testGetUserData() {
    try {
		const response = await fetch('http://localhost:3000/api/user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
				username: 'Test',
				password: '1'
			})
        });
        console.log(response);
    } catch (error) {
        console.error('Error testing get user data:', error.response.data);
    }
}

// Function to test update password endpoint
async function testUpdatePassword() {
    try {
		const response = await fetch('http://localhost:3000/api/update-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
				username: 'Test',
				currentPassword: '1',
				newPassword: '2'
			}),
        });
        console.log(response);
    } catch (error) {
        console.error('Error testing update password:', error.response.data);
    }
}

// Call the test functions
testSignUp();
testLogin();
createGenre();
testGetUserData();
testUpdatePassword();
